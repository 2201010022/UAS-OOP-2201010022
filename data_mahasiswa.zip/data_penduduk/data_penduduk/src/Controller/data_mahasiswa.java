/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author acera
 */
public class data_mahasiswa {
     Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    private String sql;
    public String nim;
    public String nama;
    public String sertifiksi;
    public String jenis_kelamin;
    public String agama;
    public String status;
    public String jadwal;
    
    public void simpan ()throws SQLException{
        conn = Koneksi.getKoneksi();
        sql = "INSERT INTO data(NIM,Nama,Sertifikasi,Jenis_Kelamin,Agama,Status,Jadwal)VALUES(?,?,?,?,?,?,?)";
        pst = conn.prepareStatement(sql);
        pst.setString(1,nim);
        pst.setString(2,nama);
        pst.setString(3,sertifiksi);
        pst.setString(4,jenis_kelamin);
        pst.setString(5,agama);
        pst.setString(6,status);
        pst.setString(7,jadwal);
        pst.execute();
        pst.close();
    }
    
        public void rubah ()throws SQLException{
        conn = Koneksi.getKoneksi();
        String sql = "UPDATE data set Nama=?,Sertifikasi=?,Jenis_Kelamin=?,Agama=?,Status=?,Jadwal=? where NIM=?";
        pst = conn.prepareStatement(sql);
        pst.setString(1,nim);
        pst.setString(2,nama);
        pst.setString(3,sertifiksi);
        pst.setString(4,jenis_kelamin);
        pst.setString(5,agama);
        pst.setString(6,status);
        pst.setString(7,jadwal);
        pst.execute();
        pst.close();
    }
        public void hapus ()throws SQLException{
            conn=Koneksi.getKoneksi();
           String sql = "DELETE from data where nip=?";
           try{
               pst=conn.prepareStatement(sql);
               pst.setString(1, nim);
               pst.execute();
           }catch (Exception e){
               JOptionPane.showMessageDialog(null, e);
           }
        }
        public ResultSet UpdateJTable()throws SQLException{
            conn = Koneksi.getKoneksi();
            sql = "select NIM,Nama,Sertifikasi,Jenis_Kelamin,Agama,Status,Jadwal from data";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            return rs;
        }
}

    

